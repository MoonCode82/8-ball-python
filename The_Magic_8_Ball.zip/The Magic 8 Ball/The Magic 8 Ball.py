import random, string
from rich import print as rprint
f = open(r"list.txt", "r")
answer_list = f.readlines()
rprint("[pink]What is your name?[/pink]")
name = input("- ")
name = string.capwords(name)
rprint(f"[green]{name}[/green][pink], what is your question?[/pink]")
input("- ")
rprint(f"[bold purple]The Magic 8 Ball: [/bold purple][italic yellow]{answer_list[random.randint(0, len(answer_list)-1)][:-2]}.[italic yellow]")
rprint("[bold red]Press ENTER to close.[/bold red]")
input("")